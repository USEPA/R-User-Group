(function($) {
    $(document).ready(function() {
	
	$('#animation_plot').scianimator({
	    'images': ['images/animation_plot1.png', 'images/animation_plot2.png', 'images/animation_plot3.png', 'images/animation_plot4.png', 'images/animation_plot5.png'],
	    'width': 600,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#animation_plot').scianimator('play');
    });
})(jQuery);
